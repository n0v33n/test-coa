This is only just 4 bit alu implemented on logisim software and given the extension of adder and subtractor.
If wanted for multiplier and divisor mail me-   pranaypatil@mitaoe.ac.in   

 ps: no charges will be there. 


steps

open logisim first 
in it open all the .circ files
files in order as 
1) 4 BIT ALU.cir
2) 4BITADDER.circ
3) 4BIT SUBTRACTORmodified.circ